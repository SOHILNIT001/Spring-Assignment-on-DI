
public class Department {
	private long id;
	private String dname;
	public Department() {}
	public Department(long id, String dname) {
		super();
		this.id = id;
		this.dname = dname;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	@Override
	public String toString() {
		return "Department [id=" + id + ", dname=" + dname + "]";
	}
}
