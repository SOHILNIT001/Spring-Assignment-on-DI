/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package springautowiringbytype;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;  


/**
 *
 * @author ADMIN
 */
@Configuration
class ConfigClass{
	@Bean
	Address getAddress(){
		return new Address();
	}
	
	@Bean
	Department getDepartment() {
		return new Department();
	}
	
	@Bean
	@Qualifier("mno")
	Salary getSalary(){
		return new Salary();
	}
	
	@Bean
	@Qualifier("mno1")
	Salary getSalary1(){
		return new Salary();
	}
	
	@Bean
	Employee getEmployee(){
		return new Employee();
	}
	
}

//@Configuration
//class ConfigClass1{
//	
//	@Bean
//	Employee giveEmployee(){
//		return new Employee();
//	}
//}

public class SpringAutoWiringbyType {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        ApplicationContext context = 
//             new AnnotationConfigApplicationContext(ConfigClass.class);

//      Employee te = context.getBean(Employee.class);
//      te.spellCheck();
        ApplicationContext context = 
                new AnnotationConfigApplicationContext(ConfigClass.class);
      
//      Employee te = context.getBean(Employee.class);
//      te.spellCheck();
      
      //4 sol
      Department dept =  context.getBean(Department.class);
      dept.setId(123);
      dept.setDname("IT");
      System.out.println(dept);
    }
    
}
