package SpringAssignmentonDI_Q1sol;

public class XyzEMail {
	public XyzEMail(){
		System.out.println("XyzEMail() constructor.......");
	}
	public void sendMail() {
		System.out.println("sending the mail.......");
	}

	public void recvMail() {
		System.out.println("receving the email....");
	}
}
