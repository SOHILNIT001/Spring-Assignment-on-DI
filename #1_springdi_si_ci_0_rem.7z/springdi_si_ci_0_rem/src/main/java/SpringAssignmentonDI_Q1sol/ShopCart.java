package SpringAssignmentonDI_Q1sol;

public class ShopCart {
	ShopCart(){
		System.out.println("Shopcart obj created..........");
	}
	
	void addItems() {
		System.out.println("Items added.......");
	}
	
	void makePayment() {
		System.out.println("Payment successfully done.........");
	}
}
