package com.eg;

public class Salary {
	private long tranId;	
	private float amount;
	public Salary() {
		System.out.println("salary() called");
	}
	public Salary(long tranId, float amount) {
		super();
		this.tranId = tranId;
		this.amount = amount;
	}
	public long getTranId() {
		return tranId;
	}
	public void setTranId(long tranId) {
		this.tranId = tranId;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Salary [tranId=" + tranId + ", amount=" + amount + "]";
	}
}
