package com.eg1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.eg2.Product;

@Component
public class ShoppingCart {
	
	ArrayList<Product> list = new ArrayList<Product>();
	
	public String addItem(long id,String item_name,float price){
		list.add(new Product(id, item_name, price));
		return item_name+" is added";
	}
	
	public ArrayList<Product> getProductLists(){
		return list;
	}
}
