package com.eg;

import org.springframework.stereotype.Component;

@Component
public class B {
	B() {
		System.out.println("B()");
	}
}
