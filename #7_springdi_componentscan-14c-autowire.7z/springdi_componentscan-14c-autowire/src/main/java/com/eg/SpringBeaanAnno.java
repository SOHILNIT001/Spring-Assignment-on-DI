package com.eg;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.eg1.ShoppingCart;
import com.eg2.Product;

@Configuration
@ComponentScan(basePackages = { "com.eg", "com.eg1" ,"com.eg2"})
public class SpringBeaanAnno {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(SpringBeaanAnno.class);

		// ctx.register(MyConfig.class);
		// ctx.refresh();

		A oa = ctx.getBean(A.class);
		System.out.println(oa);

		Employee emp = (Employee) ctx.getBean("empp", oa);
		emp.setName("pqrst");

		System.out.println(emp.getName());

		A oa1 = ctx.getBean(A.class);
		ShoppingCart scart = ctx.getBean(com.eg1.ShoppingCart.class);
		System.out.println(scart.addItem(123,"Mobile Phone",2123));
		
		System.out.println("_____________________________________________________________________");
		List<Product> products = scart.getProductLists();
		for(Product p : products) {
			System.out.println(p);
		}
	}
}
